<div class="page-header">
  <h1>{!! App::title() !!}</h1>
</div>
